# Ruben Lazell
# 40679914
# Option A

import numpy as np
import sys as sys

def main():

    
    filename = sys.argv[1] + ".cav"
    result = A_star(filename)
    
    # Write the result to the output file
    output_name = sys.argv[1] + ".csn"
    with open(output_name, "w") as output:
        output.write(result)


def read(filename):
    with open(filename, 'r') as file:
        data = file.read().split(',')
        
    number_of_caverns = int(data[0])

    coords = [(int(data[i]), int(data[i + 1])) for i in range(1, 2 * number_of_caverns, 2)]
        
    mat = ((np.array(data[2 * number_of_caverns + 1:], dtype=int)).reshape((number_of_caverns, number_of_caverns))).T
        
    return number_of_caverns, coords, mat


def euclidean_dist(x1, x2, y1, y2):
    return np.sqrt(((x2 - x1) ** 2) + ((y2 - y1) ** 2))


def A_star(filename):
    number_of_caverns, coords, mat = read(filename)
    node_to_index = {node: index for index, node in enumerate(coords)}
    current_node = coords[0]
    final_node = coords[-1]
    found = False
    open_set = []
    closed_set = []
    open_counter = 0
    

        
    
    g_values = {node: float('inf') for node in coords}
    #{(2, 8): inf, (3, 2): inf, (14, 5): inf, (7, 6): inf, (11, 2): inf, (11, 6): inf, (14, 1): inf}

    g_values[current_node] = 0 
    #{(2, 8): 0, (3, 2): inf, (14, 5): inf, (7, 6): inf, (11, 2): inf, (11, 6): inf, (14, 1): inf}

    parents = {node: None for node in coords}
    #{(2, 8): None, (3, 2): None, (14, 5): None, (7, 6): None, (11, 2): None, (11, 6): None, (14, 1): None}    
    while not found:

    
        for i in range(number_of_caverns):

            if mat[node_to_index[current_node],i] == 1:

                
                #g_values
                #{(2, 8): 0, (3, 2): 11.042019056626884, (14, 5): 12.547442467302885
                #, (7, 6): 5.385164807134504, (11, 2): 11.042019056626884
                #, (11, 6): 9.385164807134505, (14, 1): inf}

                g = euclidean_dist(current_node[0], coords[i][0], current_node[1], coords[i][1]) + g_values[current_node]

                h = euclidean_dist(coords[i][0], coords[-1][0], coords[i][1], coords[-1][1])
                f = g+h


    
                #if we get to a node in a quicker way than ever before, update g dictionary
                if g < g_values[coords[i]]:
                    g_values[coords[i]] = g
    
                    node_in_open_set = False
                    for j in open_set:
                        if j[0] == i:
                            j[1] = f
                            parents[coords[i]] = current_node #best path to coords[i]  comes from current_node

                            node_in_open_set = True
    
                    if not node_in_open_set:
    
                        open_set.append([i, f])
                        parents[coords[i]] = current_node

        if open_set:
            min_f = open_set[0][1] #initialise
            min_index = 0
            for i in range(1, len(open_set)):
                if open_set[i][1] < min_f and coords[open_set[i][0]] not in closed_set:

                    min_f = open_set[i][1]
                    min_index = i
            current_node = coords[open_set[min_index][0]]
            closed_set.append(current_node)  # Add current_node to the closed_set

            open_set.pop(min_index)

            if current_node == final_node:
                found = True


        if not open_set:
            open_counter+=1
        if open_counter > 10:
            return '0' 



    
    path = []
    current = final_node
    while current is not None:
        path.insert(0, current)
        current = parents[current]
    
    
    for i in range(len(path)):
        path[i] = node_to_index[path[i]]+1

    path = ' '.join(map(str, path))  
    return path

if __name__ == "__main__":
    main()

